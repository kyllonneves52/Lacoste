# Checklist de integração SMS/MB

Servidor: https://lacoste.hyzecloud.app

- Pedido contém referência e montante esperados.
- SMS deve ser de recebimento, nunca apenas comprovativo de envio.
- Referência, montante e operador são comparados antes de liberar o pedido.
- SMS sem correspondência é guardado na `verification_inbox` por até 10 minutos; `stored: true` não é aprovação de pagamento.
- Só `status: verified` autoriza a etapa seguinte de notificação FCM.
- O FCM deve apontar ao Android ID do Lacoste Auto associado, mesmo que LC Verification esteja noutro telefone.
- O estado final da transferência deve voltar à API para o bot comunicar o resultado.
- Validar pedidos divididos, duplicados, timeout, SMS tardio, ID incorreto e valor incorreto.

Não colocar tokens/segredos no repositório. Fazer backup antes de aplicar migrações SQL. O código-fonte ainda requer build dos APKs e teste de integração no servidor real.
