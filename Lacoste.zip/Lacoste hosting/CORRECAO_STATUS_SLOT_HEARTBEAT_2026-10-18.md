CORRECAO_STATUS_SLOT_HEARTBEAT_2026-10-18.md
================================================

Problemas encontrados no código da API:
1. A aprovação calculava slots usando também registos antigos/expirados e não excluía o Android ID que estava a ser re-aprovado. Um aparelho com slot antigo podia ser contado como ocupante do slot 1 e receber slot 2.
2. O endpoint de registo não atualizava last_seen em todos os registos. Por isso o bot podia mostrar N/D mesmo depois de o APK ter acabado de contactar a API.
3. O endpoint /api/autosistema/dispositivo/status não devolvia lastSeen nem o estado de configuração FCM.

Alterações:
- A atribuição dos slots 1/2 considera outros dispositivos ativos e com licença válida; tenta preservar o slot válido do próprio Android ID.
- O registo bem-sucedido atualiza last_seen sem apagar nem substituir o token FCM existente quando o APK não envia um token novo.
- O endpoint de status passa a devolver lastSeen e pushConfigurado.
- O heartbeat continua a validar X-App-Token/deviceToken; não foi removida autenticação nem alterado o formato dos eventos FCM.

Importante:
- Isto corrige a lógica no código da API, mas este ZIP ainda precisa ser publicado no HyzeCloud para surtir efeito.
- Depois de publicar, abre o Lacoste Auto e inicia o monitoramento; espera 30–60 segundos e consulta .statusdispositivo.
- Se o último sinal não avançar após esse período, o heartbeat do APK está a falhar ou o monitoramento não está ativo. Verifica o log do app por "Heartbeat falhou". O valor "FCM: CONFIGURADO" apenas confirma que há token guardado, não que a entrega FCM foi testada.
- Não foi possível consultar diretamente a base Turso nem testar o servidor em produção nesta análise; por isso não afirmo que o registo específico d8a96d9dc1e0eada tenha ficado com slot 1. A lógica corrigida fará isso se não existir outro dispositivo ativo a ocupar o slot 1.
