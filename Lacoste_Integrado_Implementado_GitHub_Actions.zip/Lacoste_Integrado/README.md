# LACOSTE — projeto integrado (03/11/2026)

Este pacote reúne os dois aplicativos Android, a API e os ficheiros-fonte do bot fornecidos no `Lacoste.zip`, com melhorias de integração e segurança.

## Estrutura

- `LacosteAutoTransfer/` — aplicativo Android que envia MB/crédito. A lógica atual de transferência foi preservada.
- `LCVerificationAndroid/` — aplicativo de verificação de SMS, agora com registo gratuito por dispositivo (sem licença).
- `Lacoste API/` — API Node.js, rotas, migrações, painel e configuração de hosting.
- `Lacoste Bot/src/` — fontes JavaScript do bot WhatsApp/Baileys.
- `.github/workflows/build-lacoste-android.yml` — compila os dois APKs no GitHub Actions.
- `docs/IMPLEMENTACAO_LACOSTE_2026-11-03.md` — descrição detalhada das alterações e limitações.
- `backup/originals/` — ZIP original para recuperação.

## Compilar os APKs no GitHub Actions

1. Extrai este ZIP.
2. Envia o conteúdo da pasta `Lacoste_Integrado` para a raiz de um repositório GitHub.
3. Abre o separador **Actions**.
4. Executa **Build Lacoste Android Apps** (ou faz push para iniciar automaticamente).
5. Descarrega os dois artefactos: `Lacoste-Auto-Transfer-debug` e `LC-Verification-debug`.

O workflow usa Java 17, Gradle 8.2 e Android SDK 33/build-tools 33.0.2. O ambiente desta sessão não tinha Android SDK/Gradle instalado, portanto a compilação final precisa de ser confirmada pela execução do workflow.

## API

A API está em `Lacoste API/`. Configura no hosting as variáveis de ambiente indicadas em `.env.example`. Não publiques `.env` nem tokens reais no GitHub.

Comando de arranque no hosting: `npm start` (equivalente a `node server.js`).

## Bot

Os ficheiros-fonte fornecidos estão em `Lacoste Bot/src/`. O ZIP de origem não incluía o `package.json` do bot; por isso não inventei versões de dependências nem um manifesto de arranque. Mantém o `package.json` já usado no teu hosting do bot.

## Certificação de pagamentos no bot

- `.config sms todos` — certifica todos os provedores suportados (M-Pesa/Vodacom e E-Mola).
- `.config sms voda` — apenas M-Pesa/Vodacom.
- `.config sms emola` — apenas E-Mola.
- `.config sms off` — desativa a certificação e mantém o fluxo normal atual.

Com a certificação ligada, o bot informa que o pagamento ainda aguarda confirmação durante até 10 minutos. Só quando o LC Verification envia o SMS oficial que coincide com referência, valor, provedor e dispositivo a API liberta o pedido para o Lacoste Auto. Se o prazo expirar, o bot informa que o pagamento não foi verificado e não envia MB.

## FCM e lógica existente

Os serviços Firebase/FCM existentes dos dois apps foram mantidos sem alterações. A licença do Lacoste Auto também foi preservada; a remoção de licença aplica-se apenas ao LC Verification.
