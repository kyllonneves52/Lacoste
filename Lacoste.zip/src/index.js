const { iniciar } = require('./connect');

// O bot deve registrar erros fatais para sabermos a causa em vez de
// simplesmente desaparecer do servidor.
process.on('uncaughtException', (err) => {
  console.error('🔥 UNCAUGHT EXCEPTION — BOT NÃO SERÁ ENCERRADO');
  console.error(err?.stack || err);
});

process.on('unhandledRejection', (reason) => {
  console.error('🔥 UNHANDLED REJECTION — BOT NÃO SERÁ ENCERRADO');
  console.error(reason?.stack || reason);
});

process.on('warning', (warning) => {
  console.warn('⚠️ NODE WARNING:', warning?.stack || warning);
});

console.log("Iniciando Lacoste Bot V7...");

// Pareamento pedido pelo app Lacoste Auto (independe da sessão principal).
try {
  require('./pairingApp').iniciarPairingApp();
} catch (err) {
  console.error('❌ Falha ao iniciar pareamento via app:', err?.stack || err);
}

iniciar().catch((err) => {
  console.error('❌ Falha ao iniciar o bot:', err?.stack || err);
  // O AUTO_RESTART do servidor pode reiniciar o processo, mas deixamos
  // a causa registrada no log.
});
