# LACOSTE AUTO — painel

Esta versão inclui associação individual de dispositivos por aluguel.

## Limite de dispositivos

Cada chave/aluguel pode ter até **2 dispositivos ativos**. Cada aparelho é identificado pelo Android ID e recebe um token individual depois da aprovação.

## Segurança dos pedidos

Um app só recebe pedidos cujo `device_android_id` seja exatamente o Android ID dele. Pedidos sem dispositivo associado ficam aguardando associação pelo bot.

## Rotas novas para o bot

- `POST /api/bot/dispositivos/listar`
- `POST /api/bot/dispositivo/associar`
- `POST /api/bot/dispositivo/desassociar`

Essas rotas usam `X-Bot-Token` e serão usadas na próxima integração do `sistemaVendas.js`.

## Variáveis Vercel

- `POSTGRES_URL` ou conexão suportada pelo projeto
- `ADMIN_PASSWORD`
- `LACOSTE_BOT_TOKEN`

Depois de publicar uma atualização, execute o endpoint `/api/setup` com a senha administrativa se o banco já existir, para aplicar a coluna de slot e os índices novos.

## Push FCM
O projeto está preparado para FCM. No Vercel, configure `FIREBASE_PROJECT_ID`, `FIREBASE_CLIENT_EMAIL` e `FIREBASE_PRIVATE_KEY` de uma conta de serviço Firebase. O Android usa `FIREBASE_API_KEY`, `FIREBASE_APP_ID`, `FIREBASE_PROJECT_ID` e `FIREBASE_MESSAGING_SENDER_ID` em `gradle.properties`. Sem essas credenciais, o sistema continua registando dispositivos, mas não envia push.


## Fluxo de aluguel — Grupo → Device

1. O cliente instala e abre o APK.
2. O APK registra automaticamente o Android ID, token do dispositivo e token FCM.
3. O cliente coloca o bot no grupo.
4. Um administrador do grupo envia `.idgrupo`.
5. O cliente/dono do grupo envia o ID que termina em `@g.us` ao dono do serviço.
6. No painel LACOSTE AUTO, em **Associar grupo ao dispositivo**, o dono escolhe o Device ativo e cola o ID do grupo.
7. No grupo, o administrador executa `.automacao on`. O bot apenas confirma a associação já feita no painel.
8. Quando surgir um pedido, a API usa o vínculo do grupo para escolher o Android ID correto e envia o push FCM somente para esse aparelho.
9. O APK valida Android ID + token + licença antes de executar.
10. Para trocar o aparelho, basta registrar o novo Device e alterar a associação do grupo no painel.
11. Para parar a automação, use `.automacao off` no grupo ou **Desassociar** no painel.

O cliente não precisa descobrir nem digitar o Android ID.
