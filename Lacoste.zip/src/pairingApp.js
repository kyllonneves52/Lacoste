// ============================================================
// PAREAMENTO PEDIDO PELO APP (Lacoste Auto)
// App -> API (pedido) -> ESTE POLLER -> connect.js gera o código
// -> API (resultado) -> App mostra o código e o gestor só copia.
// ============================================================
const fs = require('fs');
const path = require('path');
const { conectarNovoNumero, apagarSessao } = require('./connect');
const { apiPost } = require('./sistemaVendas');

const INTERVALO_MS = 1000;
let ativo = false;
let ocupado = false;
let ultimoErroLog = 0;

// numero -> sessão criada no último pedido (para limpar sessões que nunca foram vinculadas)
const ultimaSessaoPorNumero = new Map();

function sessaoJaVinculada(caminho) {
  try {
    const creds = JSON.parse(fs.readFileSync(path.join(caminho, 'creds.json'), 'utf8'));
    return creds && creds.registered === true;
  } catch {
    return false;
  }
}

function limparSessaoAntiga(numero) {
  const antigo = ultimaSessaoPorNumero.get(numero);
  if (!antigo) return;
  const caminho = `./sessions/${antigo}`;
  try {
    if (fs.existsSync(caminho) && !sessaoJaVinculada(caminho)) {
      apagarSessao(caminho);
      console.log(`🧹 Sessão não vinculada removida: ${antigo}`);
    }
  } catch (e) {
    console.log('⚠️ Não foi possível limpar sessão antiga:', e.message);
  }
}

async function processarPedido(p) {
  const numero = String(p.numero || '').replace(/\D/g, '');
  console.log(`📲 Pedido de código do app: ${numero} (${p.sessao})`);

  let resultado;
  try {
    limparSessaoAntiga(numero);
    resultado = await conectarNovoNumero(numero);
    if (resultado && resultado.ok && resultado.sessao) {
      ultimaSessaoPorNumero.set(numero, resultado.sessao);
    }
  } catch (e) {
    resultado = { ok: false, erro: e.message };
  }

  try {
    await apiPost('/api/bot/pairing/resultado', {
      sessao: p.sessao,
      ok: !!(resultado && resultado.ok),
      codigo: resultado && resultado.codigo,
      erro: resultado && resultado.erro
    });
    console.log(resultado && resultado.ok
      ? `✅ Código ${resultado.codigo} enviado ao app (${numero})`
      : `❌ Falha ao gerar código (${numero}): ${resultado && resultado.erro}`);
  } catch (e) {
    console.log('❌ Não consegui enviar o resultado à API:', e.message);
  }
}

async function ciclo() {
  if (!ativo || ocupado) return;
  ocupado = true;
  try {
    const r = await apiPost('/api/bot/pairing/pendentes', {});
    for (const p of (r.pedidos || [])) {
      await processarPedido(p);
    }
  } catch (e) {
    // Evita encher o log se a API estiver offline: 1 aviso a cada 60s.
    if (Date.now() - ultimoErroLog > 60000) {
      ultimoErroLog = Date.now();
      console.log('⚠️ Pareamento app: API indisponível:', e.message);
    }
  } finally {
    ocupado = false;
  }
}

function iniciarPairingApp() {
  if (ativo) return;
  ativo = true;
  console.log('🔗 Pareamento via app ativo (consulta a API a cada 1s).');
  setInterval(ciclo, INTERVALO_MS);
}

module.exports = { iniciarPairingApp };
