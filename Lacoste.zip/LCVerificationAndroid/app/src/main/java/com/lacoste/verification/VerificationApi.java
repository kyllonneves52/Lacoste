package com.lacoste.verification;

import android.content.Context;
import android.os.Build;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import org.json.JSONObject;

public final class VerificationApi {
    private static final String BASE = "http://fi4.bot-hosting.cloud:25152";
    private VerificationApi() {}

    static JSONObject req(String path, String method, JSONObject body, String token, String deviceId) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(BASE + path).openConnection();
        c.setRequestMethod(method);
        c.setConnectTimeout(15000);
        c.setReadTimeout(15000);
        c.setRequestProperty("Content-Type", "application/json");
        if (token != null && !token.isEmpty()) {
            c.setRequestProperty("X-App-Token", token);
            c.setRequestProperty("X-Verification-Token", token);
        }
        if (deviceId != null && !deviceId.isEmpty()) {
            c.setRequestProperty("X-Verification-Device", deviceId);
        }
        if (body != null) {
            c.setDoOutput(true);
            try (OutputStream o = c.getOutputStream()) {
                o.write(body.toString().getBytes(StandardCharsets.UTF_8));
            }
        }
        int status = c.getResponseCode();
        InputStream in = status >= 400 ? c.getErrorStream() : c.getInputStream();
        StringBuilder s = new StringBuilder();
        if (in != null) {
            try (BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
                String l;
                while ((l = r.readLine()) != null) {
                    if (s.length() > 0) s.append('\n');
                    s.append(l);
                }
            }
        }
        c.disconnect();
        String raw = s.toString().trim();
        JSONObject result;
        try {
            result = (raw.startsWith("{") || raw.startsWith("[")) ? new JSONObject(raw) : new JSONObject();
        } catch (Exception ignored) {
            result = new JSONObject();
        }
        if (!result.has("message") && !result.has("error") && !raw.isEmpty() && !raw.startsWith("{")) {
            String msg = raw;
            if (status == 402 || raw.toLowerCase(java.util.Locale.ROOT).contains("payment required")
                    || raw.toLowerCase(java.util.Locale.ROOT).contains("deployment_disabled")) {
                msg = "Deploy desativado no servidor (Payment required / HTTP 402). Ative o projeto ou verifique o plano.";
            } else if (raw.length() > 200) {
                msg = raw.substring(0, 200) + "…";
            }
            result.put("message", msg);
        }
        result.put("httpStatus", status);
        if (status < 200 || status >= 300) result.put("ok", false);
        return result;
    }

    public static JSONObject requestLicense(Context c, String key) throws Exception {
        JSONObject b = new JSONObject();
        b.put("licenseKey", key.toUpperCase());
        b.put("androidId", VerificationStore.deviceId(c));
        b.put("model", Build.MANUFACTURER + " " + Build.MODEL);
        b.put("deviceRole", "verification");
        b.put("platform", "android");
        return req("/api/licenca/request", "POST", b, null, null);
    }

    public static JSONObject status(Context c) throws Exception {
        return req(
            "/api/licenca/status?androidId=" + URLEncoder.encode(VerificationStore.deviceId(c), "UTF-8")
                + "&requestId=" + URLEncoder.encode(VerificationStore.requestId(c), "UTF-8"),
            "GET", null, null, null);
    }

    public static JSONObject register(Context c, String fcm) throws Exception {
        JSONObject b = new JSONObject();
        b.put("deviceId", VerificationStore.deviceId(c));
        b.put("androidId", VerificationStore.deviceId(c));
        b.put("fcmToken", fcm == null ? "" : fcm);
        b.put("deviceRole", "verification");
        JSONObject r = req("/api/autosistema/verificacao/registar", "POST", b, VerificationStore.token(c), VerificationStore.deviceId(c));
        if (r.optBoolean("ok") && !r.optString("verificationToken").isEmpty()) VerificationStore.setToken(c, r.optString("verificationToken"));
        return r;
    }

    public static JSONObject associarMb(Context c, String mbAndroidId, String fcm) throws Exception {
        JSONObject b = new JSONObject();
        b.put("deviceId", VerificationStore.deviceId(c));
        b.put("mbAndroidId", mbAndroidId);
        b.put("fcmToken", fcm == null ? "" : fcm);
        b.put("token", VerificationStore.token(c));
        return req("/api/lcverification/associar", "POST", b, VerificationStore.token(c), VerificationStore.deviceId(c));
    }


    public static JSONObject finance(Context c, JSONObject body) throws Exception {
        if (body == null) body = new JSONObject();
        body.put("deviceId", VerificationStore.deviceId(c));
        body.put("token", VerificationStore.token(c));
        return req("/api/lcverification/finance", "POST", body, VerificationStore.token(c), VerificationStore.deviceId(c));
    }

    public static JSONObject verifySms(Context c, String text, String sender, String paymentId, double amount, String provider) throws Exception {
        JSONObject b = new JSONObject();
        b.put("deviceId", VerificationStore.deviceId(c));
        b.put("token", VerificationStore.token(c));
        b.put("text", text == null ? "" : text);
        b.put("sms", text == null ? "" : text);
        b.put("sender", sender == null ? "" : sender);
        b.put("paymentId", paymentId == null ? "" : paymentId);
        if (amount > 0) b.put("amount", amount);
        if (provider != null) b.put("provider", provider);
        return req("/api/lcverification/sms", "POST", b, VerificationStore.token(c), VerificationStore.deviceId(c));
    }

    public static JSONObject verify(Context c, String pedidoId, String paymentId) throws Exception {
        JSONObject b = new JSONObject();
        b.put("deviceId", VerificationStore.deviceId(c));
        b.put("pedidoId", pedidoId);
        b.put("paymentId", paymentId);
        return req("/api/autosistema/verificacao/pagamento", "POST", b, VerificationStore.token(c), VerificationStore.deviceId(c));
    }
}