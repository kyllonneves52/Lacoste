# Lacoste — integração segura com LC Verification e ideias do Venda Auto

## Preservação
- O Lacoste Auto Transfer mantém o seu fluxo de MB/crédito, SIM, limites, saldo, número fixo, monitor e permissões.
- Os ficheiros `FirebasePushService.java`, `FirebaseConfig.java` e a lógica de envio FCM do Lacoste Auto não foram alterados.
- O FCM do LC Verification também não foi reescrito: mantêm-se os mesmos serviços, tipos de mensagens e fluxo de registo do token Firebase.
- A licença do Lacoste Auto continua intacta. A licença foi removida apenas do LC Verification; esse app faz registo gratuito e recebe um token técnico por dispositivo para autenticar a API.

## Correções implementadas
1. `SmsReceiver` recolhe o remetente real de `SmsMessage.getOriginatingAddress()` e passa-o ao `VerificationProcessor`.
2. `VerificationStore` conserva o remetente no histórico local e numa fila de saída persistente.
3. `VerificationProcessor` reenvia SMS válidos pendentes com tentativas espaçadas e retoma a fila ao abrir o app/recuperar rede. O envio à API é idempotente.
4. `/api/lcverification/sms` exige sempre ID + token ativo; token vazio já não autoriza.
5. `/api/lcverification/associar` exige token válido; removido o fallback que procurava o dispositivo sem token.
6. O LC Verification não mostra nem pede licença; regista o dispositivo automaticamente e mantém a associação mainMB.
7. Foi criada a rota `/api/lcverification/finance`, com autenticação por token, dashboard, tabela de margens e pesquisa de referência, no contrato que o app já chama.
8. A autenticação das rotas de estatísticas e configuração de lucro do Auto agora exige Android ID + token válido.
9. Referências de pagamento já associadas a pedidos pendentes, verificados ou expirados não podem ser reutilizadas para criar outro pedido.
10. SMS com a mesma referência/valor em pedidos independentes é tratado como ambíguo e não liberta pedidos automaticamente.
11. Pedidos divididos em partes, quando a certificação está ativa, partilham um ID-pai e só libertam o envio depois de todas as partes estarem registadas e a confirmação estar validada.
12. O endpoint de estado devolve dados de verificação e o prazo correto de 10 minutos.
13. O Lacoste Auto ganhou uma página de diagnóstico USSD com registo local dos menus/estados observados. Números são ocultados nesse relatório; a lógica de respostas USSD não foi alterada.

## Comportamento de pagamento no bot
- `.config sms todos`: valida recebimentos M-Pesa/Vodacom e E-Mola.
- `.config sms voda`: valida apenas M-Pesa/Vodacom.
- `.config sms emola`: valida apenas E-Mola.
- `.config sms off`: mantém o fluxo normal sem esperar pela certificação SMS.
- Com certificação ligada, o bot cria o pedido como `waiting_verification` e responde que o pagamento ainda não foi verificado, com prazo de até 10 minutos. Não afirma que o pagamento foi confirmado e não envia MB antes da validação.
- Se o SMS oficial chegar dentro do prazo e corresponder à referência, valor, operadora e dispositivo, a API liberta o pedido para o Lacoste Auto através do mesmo fluxo FCM existente.
- Se não chegar dentro de 10 minutos, o pedido expira, nenhum MB é enviado e o bot envia uma mensagem clara de pagamento não verificado.
- Se o SMS chegar antes do comprovativo, fica guardado temporariamente e é associado ao pedido quando o bot o criar.

## Ideias do Venda Auto já incorporadas nesta fase
- fila persistente de SMS, deduplicação e retentativas;
- controlo de conclusão/ambiguidade na validação financeira;
- diagnóstico de menus e estados USSD;
- auditoria da verificação e linha temporal resumida do pedido;
- painel financeiro e pesquisa de comprovativos para LC Verification;
- agrupamento seguro das partes de um pedido.

## Ainda não implementado nesta entrega
As ideias mais extensas (perfis configuráveis por operadora com editor visual, modo de simulação USSD completo, análise automática de compatibilidade por fabricante, painel central com métricas em tempo real, exportação avançada de relatórios e auditoria visual detalhada de cada evento) precisam de fases adicionais e testes em dispositivos/SIM reais. Não foram simuladas nem marcadas como concluídas.

## Compilação GitHub Actions
O workflow raiz `.github/workflows/build-lacoste-android.yml` compila os dois projetos Android em jobs separados e publica dois artefactos APK. A compilação ainda precisa de ser executada no GitHub Actions; este ambiente não tem Android SDK/Gradle instalado para validar os APKs localmente.
