# LACOSTE AUTO API — Bot-Hosting.net

Versão otimizada para o painel Bot-Hosting (não Hyze / não Discloud).

## Por que RAM / espaço estouram

- Plano free do Bot-Hosting: **256 MB RAM** e **512 MB storage**.
- A única dependência npm é `firebase-admin` (necessária para FCM push).
- O `node_modules` do firebase-admin costuma ocupar ~80–120 MB e a RAM em idle fica ~80–150 MB.
- **Nunca** faça upload de `node_modules`. Deixe o painel instalar.

## Passos de implementação (passo a passo)

### 1. Criar o deployment

1. Entre em https://bot-hosting.net
2. Projeto → **New Deployment**
3. Tipo: **Application**
4. Source: **Archive** (ou Blank + upload depois)
5. Runtime: **Node.js** (versão 20 ou 22)
6. Nome: `lacoste-auto-api` (ou o que quiser)
7. RAM: use o máximo que o plano permitir (ideal ≥ 512 MB se tiver plano pago; no free fica 256 MB)

### 2. Subir os ficheiros

1. Aba **Files**
2. Faça upload do ZIP `lacoste_auto_api_bot_hosting.zip`
3. Clique nos 3 pontos do ZIP → **Unarchive / Extract**
4. Se extrair para uma pasta (ex.: `lacoste_bot_hosting/`), **mova tudo para a raiz** do container:
   - `package.json`, `server.js`, `api/`, `lib/`, `index.html`, etc. têm de estar na raiz
5. Apague o ZIP e a pasta extra para libertar espaço

### 3. Startup (muito importante)

Na aba **Startup**:

- **Entry File / STARTUP_FILE**: `server.js`
- **Start Command** (recomendado, leve):

```bash
cd /home/container && npm install --omit=dev --no-fund --no-audit --prefer-offline && exec node server.js
```

Alternativa mais simples (se o painel já instalar pelo package.json):

```bash
node server.js
```

O código já escuta em `SERVER_PORT` (obrigatório no Bot-Hosting) e em `0.0.0.0`.

### 4. Variáveis de ambiente

Aba **Environment** / **Variables**. Cole estas (valores reais, sem aspas desnecessárias):

```
TURSO_DATABASE_URL=libsql://...
TURSO_AUTH_TOKEN=eyJ...
FIREBASE_PROJECT_ID=lacoste-auto
FIREBASE_CLIENT_EMAIL=firebase-adminsdk-...@....iam.gserviceaccount.com
FIREBASE_PRIVATE_KEY=-----BEGIN PRIVATE KEY-----\nMIIE...\n-----END PRIVATE KEY-----\n
LICENSE_TOKEN=seu_token
API_TOKEN=seu_token
ADMIN_PASSWORD=sua_senha
LACOSTE_BOT_TOKEN=seu_token_bot
```

Notas:

- `FIREBASE_PRIVATE_KEY`: uma linha só, com `\n` no meio (o código troca por quebra real).
- **NÃO** crie variável `PORT` nem `NODE_ENV` se o painel reclamar.
- O Bot-Hosting injeta `SERVER_PORT` sozinho.

### 5. Domínio / HTTPS

Aba **Domains**:

- Ative o subdomínio gratuito `*.apps.bot-hosting.cloud` (HTTPS automático).
- Ou associe o seu domínio.

Teste:

```
https://SEU-SUBDOMINIO.apps.bot-hosting.cloud/health
```

Deve devolver JSON `{ "ok": true, ... }`.

### 6. Iniciar

1. Start no painel
2. Aba **Console**: deve aparecer  
   `LACOSTE AUTO API running on http://0.0.0.0:XXXX`
3. Se der OOM / crash por RAM:
   - confirme que não subiu `node_modules`
   - use o comando com `--omit=dev --no-fund --no-audit`
   - reduza logs ou peça upgrade de RAM

## O que foi removido / otimizado

- Ficheiros Hyze / Discloud (`.env.hyze.template`, `discloud.config`, `prepare_hyze_env.sh`, etc.)
- `firebase-admin` fixado em `^12.7.0` (mais leve que 13.x em alguns casos)
- Sem outras dependências npm
- Banco continua via Turso HTTP (zero cliente extra)
- Porta: `SERVER_PORT` → `PORT` → `8080`

## Estrutura na raiz (obrigatória)

```
package.json
server.js
api/
lib/
sql/
index.html
admin.html
guia.html
sms.html
style.css
.env.example
README_BOT_HOSTING.md
```

## Troubleshooting rápido

| Problema | Solução |
|----------|---------|
| Connection timed out / 502 | App não está a escutar `SERVER_PORT` + `0.0.0.0` (já corrigido neste ZIP) |
| Cannot find module 'firebase-admin' | Falta `package.json` na raiz ou npm install falhou |
| Out of memory / crash | Plano free 256 MB é apertado para firebase-admin; use start command com `--omit=dev` e apague lixo |
| Espaço cheio | Apague ZIP + pasta extra + qualquer `node_modules` que tenha subido |
| Variáveis em falta | Console mostra aviso `[CONFIG] Variáveis ausentes: ...` |

## Ficheiros de referência

- `.env.example` — lista completa de variáveis
- `sql/` — schema se precisar de recriar tabelas no Turso
- Guias em PT (LC_VERIFICATION, SMS, etc.) mantidos para operação do bot
